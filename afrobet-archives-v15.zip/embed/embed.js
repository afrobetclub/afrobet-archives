const CSV_URL="https://docs.google.com/spreadsheets/d/e/2PACX-1vRJH1dw4bmYwPC5Yxf8zKEeQvOb7aWKnxoZ-XTuPfBn_tOVyPQjQdE-kcBcOGRzQ-Iy_1FaDvGoPjV_/pub?gid=622475547&single=true&output=csv";
let chartInstance=null;document.addEventListener("DOMContentLoaded",()=>{loadData().catch(console.error)});
function parseCSV(t){const r=[];let row=[],c="",q=false;for(let i=0;i<t.length;i++){const x=t[i],n=t[i+1];if(x=='"'&&q&&n=='"'){c+='"';i++;continue}if(x=='"'){q=!q;continue}if(x==","&&!q){row.push(c);c="";continue}if((x=="\n"||x=="\r")&&!q){if(c||row.length){row.push(c);r.push(row);row=[];c=""}if(x=="\r"&&n=="\n")i++;continue}c+=x}if(c||row.length){row.push(c);r.push(row)}return r}
function toNumber(v){return Number(String(v??"").replace(/\s/g,"").replace("%","").replace(",","."))||0}
function toDate(v){const s=String(v??"").trim();const m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(m)return new Date(Number(m[3]),Number(m[2])-1,Number(m[1]));return new Date(s)}
function formatNumber(v,d=2){return Number(v).toFixed(d).replace(".",",")}
function formatCount(v){return Number(v).toLocaleString("fr-FR")}
function dateLabel(d){return d.toLocaleDateString("fr-FR",{day:"2-digit",month:"short",year:"numeric"}).replace(".","")}
async function loadData(){const res=await fetch(CSV_URL,{cache:"no-store"});const parsed=parseCSV(await res.text());parsed.shift();const rows=parsed.filter(row=>row[0]).map(row=>({date:toDate(row[0]),result:String(row[6]||"").trim().toUpperCase(),odd:toNumber(row[5]),profit:toNumber(row[7])})).filter(row=>!isNaN(row.date)).sort((a,b)=>a.date-b.date);renderStats(rows);renderDailyChart(rows)}
function renderStats(rows){
  const total = rows.length;
  const wins = rows.filter(row => row.result.includes("WIN")).length;
  const profit = rows.reduce((s,row) => s + row.profit, 0);
  const avg = total ? rows.reduce((s,row) => s + row.odd, 0) / total : 0;
  const roiValue = total ? (profit / total) * 100 : 0;
  const winRateValue = total ? (wins / total) * 100 : 0;

  document.getElementById("profitTotal").textContent =
    `${profit >= 0 ? "+" : ""}${formatNumber(profit,2)}u`;

  document.getElementById("winRate").textContent =
    `${formatNumber(winRateValue,2)}%`;

  document.getElementById("roi").textContent =
    `${formatNumber(roiValue,2)}%`;

  document.getElementById("numberTips").textContent =
    formatCount(total);

  document.getElementById("averageOdds").textContent =
    formatNumber(avg,2);
}
function renderDailyChart(rows){let cumulative=0;const labels=[],values=[],years=[];rows.forEach(row=>{cumulative+=row.profit;labels.push(dateLabel(row.date));values.push(Number(cumulative.toFixed(2)));years.push(row.date.getFullYear())});const firstIndexByYear={};years.forEach((year,index)=>{if(firstIndexByYear[year]===undefined)firstIndexByYear[year]=index});const lastValue=values[values.length-1];const lastPointLabelPlugin={id:"lastPointLabel",afterDatasetsDraw(chart){const{ctx}=chart,meta=chart.getDatasetMeta(0),last=meta.data[meta.data.length-1];if(!last)return;ctx.save();ctx.font="700 17px Fira Code, monospace";ctx.fillStyle="#10100E";ctx.textAlign="right";ctx.textBaseline="bottom";ctx.fillText(`${lastValue>=0?"+":""}${lastValue.toFixed(2).replace(".",",")}u`,last.x-8,last.y-14);ctx.restore()}};const yearLabelPlugin={id:"yearLabels",afterDraw(chart){const{ctx,chartArea,scales}=chart,x=scales.x;ctx.save();ctx.font="500 13px Fira Code, monospace";ctx.fillStyle="#726D65";ctx.textAlign="center";ctx.textBaseline="top";Object.keys(firstIndexByYear).forEach(year=>{const index=firstIndexByYear[year],px=x.getPixelForValue(index);if(px>=chartArea.left&&px<=chartArea.right)ctx.fillText(year,Math.max(px,chartArea.left+24),chartArea.bottom+16)});ctx.restore()}};const ctx=document.getElementById("dailyChart");if(chartInstance)chartInstance.destroy();chartInstance=new Chart(ctx,{type:"line",data:{labels,datasets:[{label:"Profit cumulé",data:values,borderColor:"#123B2A",borderWidth:2,pointRadius:0,pointHoverRadius:4,pointHitRadius:12,tension:0,fill:false}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:"index",intersect:false},animation:false,layout:{padding:{top:34,right:28,bottom:38,left:18}},plugins:{legend:{display:false},tooltip:{enabled:true,backgroundColor:"#10100E",titleColor:"#F4EFE4",bodyColor:"#F4EFE4",displayColors:false,padding:12,callbacks:{title:(items)=>items&&items.length?items[0].label:"",label:(context)=>`Plus-value : ${context.parsed.y>=0?"+":""}${context.parsed.y.toFixed(2).replace(".",",")}u`}}},scales:{x:{grid:{display:false},ticks:{display:false},border:{display:false}},y:{grid:{color:"#D6CEC1"},ticks:{display:false},border:{display:false}}}},plugins:[lastPointLabelPlugin,yearLabelPlugin]})}
